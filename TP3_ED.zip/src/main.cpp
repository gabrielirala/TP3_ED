#include "include/Sistema.h"

int main() {
    Sistema sistemaLogistico;
    sistemaLogistico.executar();
    return 0;
}