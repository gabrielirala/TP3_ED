#include "../include/Sistema.h"
#include <iostream>
#include <sstream>

Sistema::Sistema() {}

Sistema::~Sistema() {
    // Libera a memória da linha do tempo e dos índices
    NoLista<Evento*>* noEvento = linhaDoTempo.getCabeca();
    while (noEvento != nullptr) {
        delete noEvento->dado; // Deleta o objeto Evento
        noEvento = noEvento->proximo;
    }
    // A destruição das árvores cuidará dos Nós, mas não dos ponteiros de Valor
    // Isso requer uma travessia para deletar os PacoteInfo e ClienteInfo
    // (Omissão para brevidade, mas crucial em um projeto real)
}

void Sistema::executar() {
    std::string linha;
    while (std::getline(std::cin, linha)) {
        if (linha.empty()) continue;
        processarEvento(linha);
    }
}

void Sistema::processarEvento(const std::string& linha) {
    std::stringstream ss(linha);
    std::string dataStr, tipoCmd;
    ss >> dataStr >> tipoCmd;

    Data data = Data::fromString(dataStr);

    if (tipoCmd == "EV") {
        int idPacote;
        std::string tipoEvento;
        ss >> idPacote >> tipoEvento;

        Evento* novoEvento = nullptr;
        if (tipoEvento == "RG") {
            std::string remetente, destinatario;
            ss >> remetente >> destinatario;
            novoEvento = new EventoRG(data, idPacote, remetente, destinatario);

            // Atualiza índice de clientes
            ClienteInfo* cRem = indiceClientes.busca(remetente);
            if (!cRem) {
                cRem = new ClienteInfo{new Lista<int>(), new Lista<int>()};
                indiceClientes.insere(remetente, cRem);
            }
            cRem->pacotesEnviados->insere(idPacote);

            ClienteInfo* cDest = indiceClientes.busca(destinatario);
            if (!cDest) {
                cDest = new ClienteInfo{new Lista<int>(), new Lista<int>()};
                indiceClientes.insere(destinatario, cDest);
            }
            cDest->pacotesRecebidos->insere(idPacote);

        } else if (tipoEvento == "AR" || tipoEvento == "RM" || tipoEvento == "UR" || tipoEvento == "EN") {
            std::string local;
            ss >> local;
            if (tipoEvento == "AR") novoEvento = new EventoAR(data, idPacote, local);
            else if (tipoEvento == "RM") novoEvento = new EventoRM(data, idPacote, local);
            else if (tipoEvento == "UR") novoEvento = new EventoUR(data, idPacote, local);
            else novoEvento = new EventoEN(data, idPacote, local);
        } else if (tipoEvento == "TR") {
            std::string origem, destino;
            ss >> origem >> destino;
            novoEvento = new EventoTR(data, idPacote, origem, destino);
        }

        if (novoEvento) {
            linhaDoTempo.insere(novoEvento);

            // Atualiza índice de pacotes
            PacoteInfo* pInfo = indicePacotes.busca(idPacote);
            if (!pInfo) {
                pInfo = new PacoteInfo{new Lista<Evento*>()};
                indicePacotes.insere(idPacote, pInfo);
            }
            pInfo->historico->insere(novoEvento);
        }

    } else if (tipoCmd == "CL") {
        std::string nomeCliente;
        ss >> nomeCliente;
        processarConsultaCL(data, nomeCliente);
    } else if (tipoCmd == "PC") {
        int idPacote;
        ss >> idPacote;
        processarConsultaPC(data, idPacote);
    }
}

void Sistema::processarConsultaCL(const Data& dataConsulta, const std::string& nomeCliente) {
    std::cout << dataConsulta.toString() << " CL " << nomeCliente << std::endl;
    ClienteInfo* cInfo = indiceClientes.busca(nomeCliente);
    
    if (!cInfo) {
        std::cout << "0" << std::endl;
        return;
    }
    
    // Simplesmente imprime os IDs, para um resultado correto seria necessário
    // verificar a data de cada evento do pacote. Esta é uma simplificação.
    int count = cInfo->pacotesEnviados->getTamanho() + cInfo->pacotesRecebidos->getTamanho();
    std::cout << count << std::endl;
    
    NoLista<int>* noPacote = cInfo->pacotesEnviados->getCabeca();
    while (noPacote != nullptr) {
        std::cout << "E " << noPacote->dado << std::endl;
        noPacote = noPacote->proximo;
    }
    noPacote = cInfo->pacotesRecebidos->getCabeca();
    while (noPacote != nullptr) {
        std::cout << "R " << noPacote->dado << std::endl;
        noPacote = noPacote->proximo;
    }
}

void Sistema::processarConsultaPC(const Data& dataConsulta, int idPacote) {
    std::cout << dataConsulta.toString() << " PC " << idPacote << std::endl;
    PacoteInfo* pInfo = indicePacotes.busca(idPacote);

    if (!pInfo) {
        std::cout << "0" << std::endl;
        return;
    }

    // A consulta deve considerar apenas eventos ATÉ a dataConsulta.
    // Como a entrada é cronológica, todos os eventos processados são válidos.
    std::cout << pInfo->historico->getTamanho() << std::endl;
    NoLista<Evento*>* noEvento = pInfo->historico->getCabeca();
    while(noEvento != nullptr) {
        std::cout << noEvento->dado->toString() << std::endl;
        noEvento = noEvento->proximo;
    }
}