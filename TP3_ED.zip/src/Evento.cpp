#include "../include/Evento.h"

// Construtor da classe base
Evento::Evento(Data dh, int id, std::string t) : dataHora(dh), idPacote(id), tipo(t) {}
Evento::~Evento() {} // Destrutor virtual

// Implementações para cada tipo de evento
EventoRG::EventoRG(Data dh, int id, std::string rem, std::string dest)
    : Evento(dh, id, "RG"), remetente(rem), destinatario(dest) {}
std::string EventoRG::toString() const {
    return dataHora.toString() + " " + tipo + " " + std::to_string(idPacote) + " " + remetente + " " + destinatario;
}

EventoAR::EventoAR(Data dh, int id, std::string l)
    : Evento(dh, id, "AR"), local(l) {}
std::string EventoAR::toString() const {
    return dataHora.toString() + " " + tipo + " " + std::to_string(idPacote) + " " + local;
}

EventoRM::EventoRM(Data dh, int id, std::string l)
    : Evento(dh, id, "RM"), local(l) {}
std::string EventoRM::toString() const {
    return dataHora.toString() + " " + tipo + " " + std::to_string(idPacote) + " " + local;
}

EventoUR::EventoUR(Data dh, int id, std::string l)
    : Evento(dh, id, "UR"), local(l) {}
std::string EventoUR::toString() const {
    return dataHora.toString() + " " + tipo + " " + std::to_string(idPacote) + " " + local;
}

EventoTR::EventoTR(Data dh, int id, std::string orig, std::string dest)
    : Evento(dh, id, "TR"), localOrigem(orig), localDestino(dest) {}
std::string EventoTR::toString() const {
    return dataHora.toString() + " " + tipo + " " + std::to_string(idPacote) + " " + localOrigem + " " + localDestino;
}

EventoEN::EventoEN(Data dh, int id, std::string l)
    : Evento(dh, id, "EN"), local(l) {}
std::string EventoEN::toString() const {
    return dataHora.toString() + " " + tipo + " " + std::to_string(idPacote) + " " + local;
}