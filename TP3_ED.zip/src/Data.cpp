#include "../include/Data.h"
#include <sstream>
#include <iomanip>

Data::Data(int a, int m, int d, int h, int min, int s)
    : ano(a), mes(m), dia(d), hora(h), minuto(min), segundo(s) {}

Data Data::fromString(const std::string& str) {
    // Formato: AAAA-MM-DD-HH:MM:SS
    return Data(
        std::stoi(str.substr(0, 4)),
        std::stoi(str.substr(5, 2)),
        std::stoi(str.substr(8, 2)),
        std::stoi(str.substr(11, 2)),
        std::stoi(str.substr(14, 2)),
        std::stoi(str.substr(17, 2))
    );
}

bool Data::operator<(const Data& outra) const {
    if (ano != outra.ano) return ano < outra.ano;
    if (mes != outra.mes) return mes < outra.mes;
    if (dia != outra.dia) return dia < outra.dia;
    if (hora != outra.hora) return hora < outra.hora;
    if (minuto != outra.minuto) return minuto < outra.minuto;
    return segundo < outra.segundo;
}

std::string Data::toString() const {
    std::ostringstream oss;
    oss << std::setfill('0')
        << std::setw(4) << ano << "-"
        << std::setw(2) << mes << "-"
        << std::setw(2) << dia << "-"
        << std::setw(2) << hora << ":"
        << std::setw(2) << minuto << ":"
        << std::setw(2) << segundo;
    return oss.str();
}