#ifndef SISTEMA_H
#define SISTEMA_H

#include "Lista.h"
#include "Arvore.h"
#include "Evento.h"

// Estruturas para armazenar nos índices
struct PacoteInfo {
    Lista<Evento*>* historico;
};

struct ClienteInfo {
    Lista<int>* pacotesEnviados;
    Lista<int>* pacotesRecebidos;
};

class Sistema {
private:
    Lista<Evento*> linhaDoTempo;
    Arvore<int, PacoteInfo*> indicePacotes;
    Arvore<std::string, ClienteInfo*> indiceClientes;

    void processarEvento(const std::string& linha);
    void processarConsultaCL(const Data& dataConsulta, const std::string& nomeCliente);
    void processarConsultaPC(const Data& dataConsulta, int idPacote);

public:
    Sistema();
    ~Sistema();
    void executar();
};

#endif // SISTEMA_H