#ifndef LISTA_H
#define LISTA_H

// Nó genérico para a lista duplamente encadeada
template <typename T>
struct NoLista {
    T dado;
    NoLista* proximo;
    NoLista* anterior;

    NoLista(T d) : dado(d), proximo(nullptr), anterior(nullptr) {}
};

// Lista duplamente encadeada genérica
template <typename T>
class Lista {
private:
    NoLista<T>* cabeca;
    NoLista<T>* cauda;
    int tamanho;

public:
    Lista();
    ~Lista();

    void insere(T dado);
    NoLista<T>* getCabeca() const;
    int getTamanho() const;
    bool vazia() const;
};

#include "../src/Lista.tpp" // Inclusão da implementação do template

#endif // LISTA_H