#ifndef ARVORE_H
#define ARVORE_H

#include <string>

// Nó genérico para a Árvore AVL
template <typename Chave, typename Valor>
struct NoArvore {
    Chave chave;
    Valor valor;
    NoArvore *esquerda;
    NoArvore *direita;
    int altura;

    NoArvore(Chave c, Valor v) : chave(c), valor(v), esquerda(nullptr), direita(nullptr), altura(1) {}
};

// Árvore AVL genérica
template <typename Chave, typename Valor>
class Arvore {
private:
    NoArvore<Chave, Valor>* raiz;

    int altura(NoArvore<Chave, Valor>* no);
    int fatorBalanceamento(NoArvore<Chave, Valor>* no);
    void atualizaAltura(NoArvore<Chave, Valor>* no);

    NoArvore<Chave, Valor>* rotacionaDireita(NoArvore<Chave, Valor>* y);
    NoArvore<Chave, Valor>* rotacionaEsquerda(NoArvore<Chave, Valor>* x);

    NoArvore<Chave, Valor>* insereRecursivo(NoArvore<Chave, Valor>* no, Chave chave, Valor valor);
    Valor buscaRecursiva(NoArvore<Chave, Valor>* no, Chave chave);
    void destruirRecursivo(NoArvore<Chave, Valor>* no);

public:
    Arvore();
    ~Arvore();

    void insere(Chave chave, Valor valor);
    Valor busca(Chave chave);
};

#include "../src/Arvore.tpp" // Inclusão da implementação do template

#endif // ARVORE_H